
## Build APK with GitHub Actions

1. Create a new GitHub repository.
2. Upload/extract all files from this project into the repository.
3. Push the files to the `main` or `master` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK**.
6. Press **Run workflow** if it has not started automatically.
7. When the job finishes, open the workflow run and download the artifact named **MugenFighter-debug-apk**.
8. The downloaded ZIP contains `app-debug.apk`.

This workflow builds the debug APK on GitHub's Ubuntu runner using JDK 17 and Gradle 9.4.1.
