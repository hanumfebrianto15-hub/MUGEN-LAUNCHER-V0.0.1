# Mugen Fighter Android 0.2 — SFF/AIR Runtime Stage

Ini adalah tahap berikutnya dari starter project.

## Baru di versi ini

- AIR parser:
  - `[Begin Action N]`
  - animation elements
  - group/image
  - X/Y offset
  - ticks
  - `LoopStart`
  - flip flags dasar
- SFF container reader:
  - signature validation
  - version fields
  - sprite table indexing
  - group/image IDs
  - width/height
  - axis
  - compression/depth metadata
- Renderer runtime:
  - memilih Action 0
  - mengikuti frame AIR berdasarkan game ticks
  - mencari sprite berdasarkan `(group,image)`
  - mencoba decode sprite raw 24-bit/32-bit
  - touch controls untuk ganti karakter

AIR memang menggunakan action yang berisi elemen sprite dengan group/image, offset, dan waktu dalam game ticks. citeturn0search1

## Batas penting

SFF 2.x memiliki data terkompresi dan format/palette yang perlu ditangani secara spesifik. Reader di versi ini sengaja **belum mengklaim full SFF v2.1 compatibility**.

Belum selesai:
- LZ5
- RLE8
- indexed/paletted sprite reconstruction
- linked sprites
- palette handling
- SFF v2.1 RGBA edge cases
- CNS/state machine
- CMD
- collision
- sound
- stages
- full MUGEN renderer

Kalau SFF karakter menggunakan format yang belum didukung decoder sederhana, UI akan tetap membaca metadata SFF tetapi menampilkan pesan bahwa sprite belum bisa didecode.

## Build

- Android Studio
- JDK 17
- Android SDK 37
- Gradle sync
- Build > Build APK(s)

Output debug:

`app/build/outputs/apk/debug/app-debug.apk`

APK belum dibuild atau diuji di perangkat dalam paket ini.

## Karakter

Pilih folder yang berisi:

chars/
  Miez/
    Miez.def
    Miez.sff
    Miez.air
    Miez.cmd
    Miez.cns

DEF menghubungkan file sprite (`sprite = ...`) dan animation (`anim = ...`) ke karakter.

## Roadmap

0.2 — SFF/AIR indexing + renderer dasar
0.3 — SFF decompression + palettes
0.4 — CNS parser/state machine
0.5 — CMD/input commands
0.6 — collision/hit system
0.7 — full battle loop
0.8 — stages/sound
1.0 — compatibility test suite
