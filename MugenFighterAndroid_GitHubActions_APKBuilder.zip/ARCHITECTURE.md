# Runtime architecture

Android storage:
DocumentFile -> ContentResolver InputStream

Character:
DEF -> asset filenames

Visual runtime:
SFF reader -> SpriteKey(group,image) -> Bitmap
AIR parser -> AirAction -> AirFrame
Animator -> current AirFrame
Renderer -> current sprite + AIR offsets

Next:
SFF decompression/palettes
    ->
CNS parser
    ->
expression evaluator
    ->
state machine
    ->
CMD command matcher
    ->
collision/physics
    ->
battle runtime
