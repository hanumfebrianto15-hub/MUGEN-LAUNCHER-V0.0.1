# Build status

Source has been checked and a compile-time bug in `RuntimeView.kt` was fixed: content resolver access now goes through `context.contentResolver`.

The supplied project uses Android Gradle Plugin 9.2.0, which requires Gradle 9.4.1 and supports API 37. This environment does not contain an Android SDK/Gradle installation and cannot download the toolchain, so an APK could not be produced here.

To build in Android Studio: open this folder, let Gradle sync/download Gradle 9.4.1 and the Android SDK, then Build > Generate App Bundles or APKs > Generate APKs.
