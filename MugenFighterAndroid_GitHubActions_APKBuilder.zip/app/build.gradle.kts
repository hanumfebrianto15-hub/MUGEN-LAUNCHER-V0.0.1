plugins { id("com.android.application") }

android {
    namespace = "com.mugenfighter"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.mugenfighter"
        minSdk = 26
        targetSdk = 37
        versionCode = 2
        versionName = "0.2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.documentfile:documentfile:1.1.0")
}
