package com.mugenfighter

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class SffSpriteKey(val group: Int, val image: Int)

data class SffSprite(
    val key: SffSpriteKey,
    val width: Int,
    val height: Int,
    val axisX: Int,
    val axisY: Int,
    val colorDepth: Int,
    val compression: Int,
    val rawData: ByteArray?
)

data class SffInfo(
    val major: Int,
    val minor: Int,
    val revision: Int,
    val spriteCount: Int,
    val sprites: List<SffSprite>
)

class SffException(message: String) : Exception(message)

object SffReader {
    private const val HEADER_SIZE = 512

    fun read(input: InputStream): SffInfo {
        val data = input.readBytes()
        if (data.size < HEADER_SIZE) throw SffException("SFF terlalu kecil")

        val sig = data.copyOfRange(0, 12).toString(Charsets.ISO_8859_1)
        if (!sig.startsWith("ElecbyteSpr")) {
            throw SffException("Bukan SFF MUGEN: signature tidak cocok")
        }

        // MUGEN SFF v2/v2.1 container header.
        val b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val major = b.get(12).toInt() and 0xff
        val minor = b.get(13).toInt() and 0xff
        val revision = b.get(14).toInt() and 0xff

        val spriteOffset = b.getInt(20)
        val spriteCount = b.getInt(24)

        if (spriteOffset < 0 || spriteOffset >= data.size) {
            throw SffException("Offset sprite SFF tidak valid")
        }

        val sprites = mutableListOf<SffSprite>()
        var pos = spriteOffset
        var guard = 0

        while (pos + 28 <= data.size && guard++ < spriteCount.coerceAtMost(200000)) {
            val h = ByteBuffer.wrap(data, pos, 28).order(ByteOrder.LITTLE_ENDIAN)
            val next = h.int
            val length = h.int
            val compression = h.get().toInt() and 0xff
            val depth = h.get().toInt() and 0xff
            val width = h.short.toInt() and 0xffff
            val height = h.short.toInt() and 0xffff
            val axisX = h.short.toInt()
            val axisY = h.short.toInt()
            val group = h.short.toInt() and 0xffff
            val image = h.short.toInt() and 0xffff
            val linked = h.short.toInt() and 0xffff
            h.short // reserved/palette field

            if (width == 0 && height == 0 && next == 0) break

            val dataStart = pos + 28
            val dataEnd = (dataStart + length).coerceAtMost(data.size)
            val raw = if (dataStart <= dataEnd && dataStart >= 0) {
                data.copyOfRange(dataStart, dataEnd)
            } else null

            sprites += SffSprite(
                SffSpriteKey(group, image),
                width, height, axisX, axisY, depth, compression, raw
            )

            if (next <= pos || next >= data.size) break
            pos = next
        }

        return SffInfo(major, minor, revision, spriteCount, sprites)
    }

    /*
     * SFF 2.x can contain compressed/indexed sprite data.
     * This method deliberately decodes only directly usable raw formats.
     * LZ5/RLE8 and palette reconstruction belong in the next compatibility step.
     */
    fun decodeSimple(sprite: SffSprite): Bitmap? {
        val raw = sprite.rawData ?: return null
        if (sprite.compression != 0) return null

        return when (sprite.colorDepth) {
            32 -> {
                val expected = sprite.width * sprite.height * 4
                if (raw.size < expected) return null
                Bitmap.createBitmap(
                    sprite.width, sprite.height,
                    Bitmap.Config.ARGB_8888
                ).also { bmp ->
                    bmp.copyPixelsFromBuffer(ByteBuffer.wrap(raw))
                }
            }
            24 -> {
                val expected = sprite.width * sprite.height * 3
                if (raw.size < expected) return null
                val out = IntArray(sprite.width * sprite.height)
                var p = 0
                for (i in out.indices) {
                    val r = raw[p++].toInt() and 255
                    val g = raw[p++].toInt() and 255
                    val bl = raw[p++].toInt() and 255
                    out[i] = -0x1000000 or (r shl 16) or (g shl 8) or bl
                }
                Bitmap.createBitmap(out, sprite.width, sprite.height, Bitmap.Config.ARGB_8888)
            }
            else -> null
        }
    }
}
