package com.mugenfighter

import java.io.InputStream

data class AirFrame(
    val group: Int,
    val image: Int,
    val x: Int,
    val y: Int,
    val ticks: Int,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val scale: Float = 1f
)

data class AirAction(
    val number: Int,
    val frames: List<AirFrame>,
    val loopStart: Int = -1
)

object AirParser {
    fun parse(input: InputStream): Map<Int, AirAction> {
        val actions = linkedMapOf<Int, MutableList<AirFrame>>()
        var current: Int? = null
        var loopStart = -1

        input.bufferedReader(Charsets.ISO_8859_1).useLines { lines ->
            lines.forEach { raw ->
                val line = raw.substringBefore(';').trim()
                if (line.isEmpty()) return@forEach

                val begin = Regex("""(?i)^\[Begin\s+Action\s+(-?\d+)]$""").find(line)
                if (begin != null) {
                    current = begin.groupValues[1].toInt()
                    actions.putIfAbsent(current!!, mutableListOf())
                    loopStart = -1
                    return@forEach
                }

                if (current == null) return@forEach
                if (line.equals("LoopStart", true)) {
                    loopStart = actions[current]!!.size
                    return@forEach
                }
                if (line.startsWith("Clsn", true)) return@forEach
                if (!line.firstOrNull()?.isDigitOrSign() == true) return@forEach

                val p = line.split(',').map { it.trim() }
                if (p.size < 5) return@forEach

                val group = p[0].toIntOrNull() ?: return@forEach
                val image = p[1].toIntOrNull() ?: return@forEach
                val x = p[2].toIntOrNull() ?: 0
                val y = p[3].toIntOrNull() ?: 0
                val ticks = p[4].toIntOrNull() ?: 1

                var fh = false
                var fv = false
                var scale = 1f
                if (p.size >= 6) {
                    val opts = p[5].lowercase()
                    fh = opts.contains("h")
                    fv = opts.contains("v")
                    Regex("""scale\s*=\s*([0-9.]+)""").find(opts)?.let {
                        scale = it.groupValues[1].toFloatOrNull() ?: 1f
                    }
                }

                actions[current]!!.add(AirFrame(group, image, x, y, ticks, fh, fv, scale))
            }
        }

        return actions.mapValues { (id, frames) ->
            AirAction(id, frames.toList(), loopStart)
        }
    }

    private fun Char.isDigitOrSign() =
        isDigit() || this == '-' || this == '+'
}
