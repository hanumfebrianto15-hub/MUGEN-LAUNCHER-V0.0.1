package com.mugenfighter

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import androidx.documentfile.provider.DocumentFile

class RuntimeView(ctx: Context, private val importAction: () -> Unit) : View(ctx) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private var chars=emptyList<MugenCharacter>()
    private var selected=0
    private var air: Map<Int,AirAction> = emptyMap()
    private var sff: SffInfo? = null
    private val animator=MugenSpriteAnimator()
    private var error=""
    private var preview: Bitmap?=null

    fun setCharacters(v:List<MugenCharacter>) {
        chars=v; selected=0; loadSelected(); invalidate()
    }

    private fun findFile(c:MugenCharacter, name:String?):DocumentFile? {
        if(name==null) return null
        return c.folder.listFiles().firstOrNull { it.isFile && it.name.equals(name,true) }
    }

    private fun loadSelected() {
        air=emptyMap(); sff=null; preview=null; error=""
        val c=chars.getOrNull(selected) ?: return
        try {
            findFile(c,c.def.animation)?.let { f ->
                context.contentResolver.openInputStream(f.uri)?.use { air=AirParser.parse(it) }
            }
            findFile(c,c.def.sprite)?.let { f ->
                context.contentResolver.openInputStream(f.uri)?.use { sff=SffReader.read(it) }
            }
            animator.setAction(air[0])
            val sprite=animator.currentFrame()
            val sp=sprite?.let { sff?.sprites?.firstOrNull { s -> s.key.group==it.group && s.key.image==it.image } }
            if(sp!=null) preview=SffReader.decodeSimple(sp)
        } catch(e:Exception) {
            error=e.message ?: "Gagal membaca aset"
        }
    }

    override fun onDraw(c:Canvas) {
        c.drawColor(Color.rgb(15,17,25))
        paint.color=Color.WHITE
        paint.textAlign=Paint.Align.CENTER
        paint.textSize=30f
        c.drawText("MUGEN 1.1 — SFF/AIR RUNTIME",width/2f,50f,paint)

        if(chars.isEmpty()) {
            paint.textSize=20f
            c.drawText("Belum ada karakter",width/2f,height/2f,paint)
            button(c,40f,height-90f,300f,height-30f,"IMPORT FOLDER")
            return
        }

        val ch=chars[selected]
        paint.textSize=25f
        c.drawText(ch.def.displayName,width/2f,100f,paint)
        paint.textSize=15f
        c.drawText("SFF sprites: ${sff?.sprites?.size ?: 0}   AIR actions: ${air.size}",width/2f,126f,paint)

        val frame=animator.currentFrame()
        val sprite=frame?.let { fr -> sff?.sprites?.firstOrNull { it.key.group==fr.group && it.key.image==fr.image } }
        val bmp=sprite?.let { SffReader.decodeSimple(it) } ?: preview

        if(bmp!=null && frame!=null) {
            val scale=minOf(3f, 360f/maxOf(1,bmp.width), 360f/maxOf(1,bmp.height))
            val w=bmp.width*scale; val h=bmp.height*scale
            val dst=RectF(width/2f-w/2, height/2f-h/2, width/2f+w/2, height/2f+h/2)
            val save=c.save()
            c.translate(frame.x.toFloat(),frame.y.toFloat())
            c.drawBitmap(bmp,null,dst,paint)
            c.restoreToCount(save)
        } else {
            paint.textSize=17f
            c.drawText(
                if(error.isNotEmpty()) error else "SFF sprite belum dapat didecode pada format ini",
                width/2f,height/2f,paint
            )
        }

        button(c,30f,height-95f,150f,height-30f,"<")
        button(c,width-150f,height-95f,width-30f,height-30f,">")
        button(c,width/2f-90,height-95f,width/2f+90,height-30f,"ACTION 0")
        postInvalidateDelayed(16)
    }

    private fun button(c:Canvas,l:Float,t:Float,r:Float,b:Float,s:String) {
        paint.color=Color.rgb(55,60,75)
        c.drawRoundRect(l,t,r,b,14f,14f,paint)
        paint.color=Color.WHITE
        paint.textSize=18f
        c.drawText(s,(l+r)/2,(t+b)/2+7,paint)
    }

    override fun onTouchEvent(e:MotionEvent):Boolean {
        if(e.action!=MotionEvent.ACTION_UP) return true
        val y=e.y; val x=e.x
        if(chars.isEmpty()) { if(y>height-110) importAction(); return true }
        if(y>height-110) {
            if(x<180) selected=(selected-1+chars.size)%chars.size
            else if(x>width-180) selected=(selected+1)%chars.size
            loadSelected(); invalidate()
        }
        return true
    }
}
