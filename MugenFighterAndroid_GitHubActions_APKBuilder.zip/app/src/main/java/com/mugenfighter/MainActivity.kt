package com.mugenfighter

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile

class MainActivity : Activity() {
    private lateinit var view: RuntimeView
    private val repo = CharacterRepository(this)

    companion object { private const val REQUEST_TREE = 900 }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        view = RuntimeView(this) { pickFolder() }
        setContentView(view)
    }

    private fun pickFolder() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            ), REQUEST_TREE
        )
    }

    @Deprecated("Prototype")
    override fun onActivityResult(req: Int, result: Int, data: Intent?) {
        super.onActivityResult(req, result, data)
        if (req != REQUEST_TREE || result != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val chars = repo.scan(uri)
        view.setCharacters(chars)
        if (chars.isEmpty()) Toast.makeText(this, "Tidak menemukan karakter .def", Toast.LENGTH_LONG).show()
    }
}

data class CharacterFiles(
    val character: MugenCharacter,
    val sff: DocumentFile?,
    val air: DocumentFile?
)

class CharacterRepository(private val activity: Activity) {
    fun scan(uri: android.net.Uri): List<MugenCharacter> {
        val root = DocumentFile.fromTreeUri(activity, uri) ?: return emptyList()
        val result = mutableListOf<MugenCharacter>()
        fun walk(f: DocumentFile, depth: Int) {
            if (depth > 4) return
            val all = f.listFiles()
            all.filter { it.isFile && it.name?.endsWith(".def", true) == true }.forEach { def ->
                val parsed = activity.contentResolver.openInputStream(def.uri)?.use {
                    MugenDefParser.parse(it, def.name!!.substringBeforeLast('.'))
                } ?: return@forEach
                result += MugenCharacter(f, def, parsed)
            }
            all.filter { it.isDirectory }.forEach { walk(it, depth + 1) }
        }
        walk(root, 0)
        return result
    }
}

data class MugenCharacter(
    val folder: DocumentFile,
    val defFile: DocumentFile,
    val def: MugenDef
)

object MugenDefParser {
    fun parse(input: java.io.InputStream, fallback: String): MugenDef {
        val map = linkedMapOf<String, MutableMap<String,String>>()
        var sec = ""
        input.bufferedReader(Charsets.ISO_8859_1).forEachLine { raw ->
            val l = raw.substringBefore(';').trim()
            if (l.startsWith("[") && l.endsWith("]")) {
                sec = l.substring(1,l.length-1).trim().lowercase()
                map.getOrPut(sec){linkedMapOf()}
            } else {
                val i=l.indexOf('=')
                if(i>0 && sec.isNotEmpty()) map[sec]!![l.substring(0,i).trim().lowercase()]=l.substring(i+1).trim()
            }
        }
        val info=map["info"].orEmpty()
        val f=map["files"].orEmpty()
        return MugenDef(
            info["name"]?.trim('"') ?: fallback,
            info["displayname"]?.trim('"') ?: fallback,
            info["mugenversion"] ?: "unknown",
            f["sprite"], f["anim"], f["cmd"],
            listOfNotNull(f["cns"],f["st"],f["stcommon"]), f["sound"], map.keys
        )
    }
}

data class MugenDef(
    val name:String,val displayName:String,val version:String,val sprite:String?,
    val animation:String?,val command:String?,val constants:List<String>,
    val sounds:String?,val rawSections:Set<String>
)
