package com.mugenfighter

import android.graphics.Bitmap
import android.os.SystemClock

class MugenSpriteAnimator {
    private var action: AirAction? = null
    private var startedAt = 0L

    fun setAction(value: AirAction?) {
        action = value
        startedAt = SystemClock.uptimeMillis()
    }

    fun currentFrame(): AirFrame? {
        val a = action ?: return null
        if (a.frames.isEmpty()) return null

        val elapsedTicks = ((SystemClock.uptimeMillis() - startedAt) * 60L / 1000L).toInt()
        var t = 0
        for ((index, frame) in a.frames.withIndex()) {
            if (frame.ticks < 0) return frame
            t += frame.ticks
            if (elapsedTicks < t) return frame
        }

        val loop = a.loopStart
        return if (loop >= 0 && loop < a.frames.size) a.frames[loop] else a.frames.last()
    }
}
